package com.talentstream.repository;

public class JwtUserRepository {

}
