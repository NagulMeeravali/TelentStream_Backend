package com.talentstream.controller;

public class AuthController {

}
